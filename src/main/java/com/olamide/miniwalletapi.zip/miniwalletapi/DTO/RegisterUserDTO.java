package com.olamide.miniwalletapi.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public record RegisterUserDTO(
        @Email(message = "Email must be valid")
        @NotBlank(message = "Email must not be empty")
        String email,

        @NotBlank(message = "Password is required")
        @Size(min=8,message = "Password must be at least 8 characters")
        String password
) {
}
